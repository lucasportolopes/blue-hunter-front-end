import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  namepart:string = '';
  id:string;
  fullName:string;
  gender:string;
  age:number;
  email:string;
  phone:string;
  username:string;
  found:boolean;

  constructor(private httpClient:HttpClient){  }
  onNameKeyUp(event:any){
    this.namepart = event.target.value;
    this.found = false;
  }
  getDados(){
    this.httpClient.get(`https://dummy-blue-hunter.mybluemix.net/user/by-name/${this.namepart}`)
    .subscribe(
      (data:any[]) => {
        if(data.length) {
          var aux = data[0].fullName.split(' ');
          console.log(aux);
          if(aux[0].toLowerCase() == this.namepart.toLowerCase()  || aux[1].toLowerCase() == this.namepart.toLowerCase() ){
          this.id = data[0].id;
          this.fullName = data[0].fullName;
          this.gender = data[0].gender
          this.age = data[0].age;
          this.email = data[0].email;
          this.phone = data[0].phone;
          this.username = data[0].username;
          this.found = true;
          }else{
            alert('Usuário não encontrado, melhore sua forma de busca.');
          }
                  }else{
                    alert('Usuário não encontrado');
        }
      }
    )
  }
}
